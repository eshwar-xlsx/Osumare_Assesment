import React from 'react';
import Card from './Card';

const Conversions_2 = () => {
  return (
    <>
      <div className="container-fluid">
        <div className="row d-flex align-items-center">
          <div className="col-md-12">
            <h1 className="text-center text-dark mt-5">
             
            </h1>
            
            <div className="col-md-12 d-flex justify-content-center align-items-center">
              <Card />
            </div>

            <p className='h1 text-center'>Lorem ipsum dolor sit amet.</p>

            <div className="col-md-12 d-flex justify-content-center  align-items-center">
              <Card />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Conversions_2;
